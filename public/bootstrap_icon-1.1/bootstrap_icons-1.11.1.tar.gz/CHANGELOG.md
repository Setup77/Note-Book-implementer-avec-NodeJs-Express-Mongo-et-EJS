## 1.11.1

- Updated to Bootstrap Icons v1.11.1.

## 1.11.0

- Updated to Bootstrap Icons v1.11.0.

## 1.10.5

- Updated to Bootstrap Icons v1.10.5.

## 1.10.2

- Updated to Bootstrap Icons v1.10.2.
- BREAKING CHANGE: changed the prefix of icons that started with number from 'number' to '$'

## 1.9.1

- Updated to Bootstrap Icons v1.9.1.

## 1.8.1

- Updated to Bootstrap Icons v1.8.1.

## 1.7.2

- Updated to Bootstrap Icons v1.7.2.

## 0.0.1

- Bootstrap Icons library v1.5.0 with over 1,300 icons.
